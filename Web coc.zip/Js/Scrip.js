const about = document.querySelector
('.about');
document.querySelector('#hamburger-menu').onclick = (e) => {
  about.classList.toggle('active');
e.preventDefault();
};

const hm= document.querySelector('#hamburger-menu');
document.addEventListener('click', function(e){
  if(!hm.contains(e.target) && !about.contains(e.target)){
    about.classList.remove('active');
}
});

