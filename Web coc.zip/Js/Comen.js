function submitComment() {
            var commentInput = document.getElementById("comment").value;
            var commentSection = document.getElementById("commentSection");

            // Check if the input is not empty before adding a comment
            if (commentInput.trim() !== "") {
                // Create a new paragraph element to display the comment
                var newComment = document.createElement("p");
                newComment.textContent = commentInput;

                // Append the new comment to the comment section
                commentSection.appendChild(newComment);

                // Clear the input field after submitting a comment
                document.getElementById("comment").value = "";
            }
        }