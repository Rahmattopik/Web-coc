var myParagraph = document.getElementById("myParagraph");

var judul = document.getElementById("judul");
var isi =document.getElementById("isi");

var peraturan = document.getElementById("peraturan1")
var peraturan2 = document.getElementById("isi_peraturan")
        // Mengganti teks elemen tersebut
        myParagraph.innerHTML = "halo kawan silahlan masuk grup coc kami diaini. di sini akan ada even menarik lainya yg bisa anda dapatkan";
        judul.innerHTML ='judul';
        isi.innerHTML = `
          1. harus mapan</br> 
          2. ganteng nya ganteng banget </br> 
          3 jadi juara satu sedunia`;
          
          peraturan.innerHTML='judul'
          peraturan2.innerHTML='1 apa </br> 2 ya begitu'
    